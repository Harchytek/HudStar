## v2.3.2
Updated to support the latest website layout and display changes.

## v2.3.1
Completely eliminate the visual misalignment of the stars.

## v2.2.1
Updated the `README` with additional information and corrections.

## v2.2.0
Fixes the visual appearance of boss stars.

## v2.1.0
Remove the visual offset of the stars when monsters appear. 

## v2.0.0
Complete code redesign to Harmony.

## v1.0.0
Initial release (Scan Hud).