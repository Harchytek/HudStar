## v2.0.0
Complete code redesign to Harmony.

## v1.0.0
Initial release (Scan Hud).