## v2.2.1
Correction of errors in the `readme`.

## v2.2.0
Fixes the visual appearance of boss stars.

## v2.1.0
Remove the visual offset of the stars when monsters appear. 

## v2.0.0
Complete code redesign to Harmony.

## v1.0.0
Initial release (Scan Hud).