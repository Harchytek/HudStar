## v2.1.0
Instead of waiting for the first `LateUpdate` cycle, the position is forced as soon as the script processes the HUD in `UpdateHuds`.

## v2.0.0
Complete code redesign to Harmony.

## v1.0.0
Initial release (Scan Hud).